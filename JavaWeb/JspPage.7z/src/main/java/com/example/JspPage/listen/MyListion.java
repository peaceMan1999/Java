package com.example.JspPage.listen;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


public class MyListion implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("创建初始化");
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("销毁");
    }
}
