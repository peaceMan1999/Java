package com.example.JspPage;

import com.example.JspPage.pojo.Student;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;

public class SearchStuents extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ArrayList<Student> students = new ArrayList<>();
        for (int i = 1; i < 10; ++i){
            students.add(new Student(1 + i, "name" + i, 18 + i, 1234+ i));
        }
        req.setAttribute("array", students);
        // 请求转发
        req.getRequestDispatcher("/test2.jsp").forward(req, resp);
    }
}
