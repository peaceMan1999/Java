package com.example.springboot_1.dao.Impl;

import com.example.springboot_1.dao.EmpDao;
import com.example.springboot_1.pojo.Emp;
import com.example.springboot_1.utils.XmlParserUtils;

import java.net.URISyntaxException;
import java.util.List;

public class EmpDaoA implements EmpDao {

    @Override
    public List<Emp> listEmp() throws URISyntaxException {
        String file = this.getClass().getClassLoader().getResource("emp.xml").toURI().getPath();
        List<Emp> empList = XmlParserUtils.parse(file, Emp.class);
        return empList;
    }
}
