package com.example.springboot_1.dao;

import com.example.springboot_1.pojo.Emp;

import java.net.URISyntaxException;
import java.util.List;

public interface EmpDao {
    public List<Emp> listEmp() throws URISyntaxException;
}
