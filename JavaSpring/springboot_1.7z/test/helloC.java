package com.example.springboot_1.test;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class helloC {
    @RequestMapping("/hello")
    public String hellotest(){
        System.out.println("hello_1");
        return "hello_2";
    }
}
