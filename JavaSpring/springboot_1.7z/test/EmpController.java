package com.example.springboot_1.test;

import com.example.springboot_1.Server.Impl.EmpServerA;
import com.example.springboot_1.pojo.Emp;
import com.example.springboot_1.pojo.Result;
import com.example.springboot_1.utils.XmlParserUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.URISyntaxException;
import java.util.List;

@RestController
public class EmpController {
    private EmpServerA empServerA = new EmpServerA();
    @RequestMapping("/listEmp")
    public Result list() throws URISyntaxException {
//        String file = "D:\\ftp文件\\第二学期\\Java EE课件\\实践课\\实验08 常用工具使用\\SpringBoot_1\\src\\main\\resources\\emp.xml"
//        String file = this.getClass().getClassLoader().getResource("emp.xml").getFile();
        List<Emp> empList = empServerA.empServer();

        return Result.success(empList);

//        String file = this.getClass().getClassLoader().getResource("emp.xml").toURI().getPath();
//        List<Emp> empList = XmlParserUtils.parse(file, Emp.class);
//
//        empList.stream().forEach(emp->{
//            String gender = emp.getGender();
//            if ("1".equals(gender)){
//                emp.setGender("男");
//            }else{
//                emp.setGender("女");
//            }
//
//            String job = emp.getJob();
//            if ("1".equals(job)){
//                emp.setJob("讲师");
//            }else if ("2".equals(job)){
//                emp.setJob("班主任");
//            }else{
//                emp.setJob("就业指导");
//            }
//        });
//        return Result.success(empList);
    }
}
