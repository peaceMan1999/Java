package com.example.springboot_1.Server.Impl;

import com.example.springboot_1.Server.EmpServer;
import com.example.springboot_1.dao.Impl.EmpDaoA;
import com.example.springboot_1.pojo.Emp;

import java.net.URISyntaxException;
import java.util.List;

public class EmpServerA implements EmpServer {
    private EmpDaoA empDaoA = new EmpDaoA();
    @Override
    public List<Emp> empServer() throws URISyntaxException {
        List<Emp> empList = empDaoA.listEmp();

        empList.stream().forEach(emp->{
            String gender = emp.getGender();
            if ("1".equals(gender)){
                emp.setGender("男");
            }else{
                emp.setGender("女");
            }

            String job = emp.getJob();
            if ("1".equals(job)){
                emp.setJob("讲师");
            }else if ("2".equals(job)){
                emp.setJob("班主任");
            }else{
                emp.setJob("就业指导");
            }
        });
        return empList;
    }
}
