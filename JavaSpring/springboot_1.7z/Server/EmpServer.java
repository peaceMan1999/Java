package com.example.springboot_1.Server;

import com.example.springboot_1.pojo.Emp;

import java.net.URISyntaxException;
import java.util.List;

public interface EmpServer {
    public List<Emp> empServer() throws URISyntaxException;
}
